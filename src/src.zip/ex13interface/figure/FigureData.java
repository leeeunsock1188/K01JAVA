package ex13interface.figure;

public class  FigureData {
		
	int width, height;
	
	public FigureData(int width, int height) {
		this.width = width;
		this.height = height;
	}

}
