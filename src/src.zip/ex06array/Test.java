package ex06array;

import java.io.IOException;
import java.util.Scanner;

public class Test {


	public static void main (String[] args)throws IOException{

		
		// 1번 문제 
//		int eng ,kor, math , avg; 
//		eng=99;
//		kor=89;
//		math=78;
//		avg = (eng+kor+math);
//		
//		System.out.println("국어:"+kor);
//		System.out.println("영어:"+eng);
//		System.out.println("수학:"+math);
//		System.out.println("총점:"+avg);
	
		//2번 문제 
//		int eng ,kor, math ; 
//		double avg;
//		eng=80;
//		kor=99;
//		math=96;
//		avg = (eng+kor+math)/3.0;
//	
//		System.out.println("평균점수:"+avg);
//		System.out.println("평균점수:"+(int)avg);

		//3번 문제 
//		int area_int = 10;
//		float area_float =0;
//		double area_double = 3.14;
		//다시 확인할것 
		
		//4번 문제 throws IOException사용 
//		Scanner scanner = new Scanner(System.in);
//		System.out.print("한자리 숫자를 입력하세요:");
//		
//		int su = System.in.read();
//		
//		if(su>=48 && su<=57) {
//			
//			if(su%2==0) {
//				System.out.println(su+"는 2의 배수입니다.");
//			}
//			else {
//				System.out.println(su+"는 2의 배수가 아닙니다.");
//			}
//		}
//		else {
//			System.out.println("숫자만 입력하세요.");
//		}
//					5번문자
//		System.out.println("숫자하나를 입력하세요");
//		int su = System.in.read();
//		String i = (su>=48 && su<=57) ? "숫자이다": "문자이다";
//		System.out.println(i);
//					6번문자
//		int num=120;
//		if(num>0 && num%2==0) {
//			System.out.println("양수이면서 짝수");
//		}
//	
		//6번 문제 
//		int num1= 50;
//		int num2 = 100;
//		int big,diff;
//		
//		if(num1>num2) {
//			big= num2;
//			diff=num1;
//		}
//		else {
//			big =num2;
//			diff= num2-num1;
//		}
//		System.out.println(big);
//		System.out.println(diff);
	
		//7번문제 
//		int i=0;
//		while(i<5){
//			int j=0;
//			while(j<=i) {
//				System.out.print("*");
//			j++;
//			}System.out.println();
//			
//			i++;
//		}
//	
		
		//8번 문제 
//		int sum=0;
//		for(int i=0; i<=100; i++) {
//			if(i%3==0 || i%7==0 ) {
//				if(i%3 == 0 && i%7==0)continue;
//				 sum += i;
//				 
//			}
//		}
//		System.out.println(sum);
//		
		//9번 문제 
//		for(int i=0; i<5; i++) {
//			for(int j=5; j>i; j--) {
//				System.out.print("*");
//			}System.out.println();
//		}
		//10번 문제
//		for(int i=2; i<=9; i++) {
//			for(int j=1; j<=9; j++) {
//				System.out.printf("%d * %d = %2d ",i,j,(i*j));
//			}System.out.println();
//		}

	
	
	
	
}
	
	static void arithmetic(int sNum , int eNum) {
		
	}
	
}